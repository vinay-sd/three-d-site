import { MutableRefObject } from 'react';
import CameraController from './CameraController';
import Particles from './Particles';
import FloatingImagePlane from './FloatingImagePlane';
import Atmosphere from './Atmosphere';
import { galleryImages } from '../../data';

interface HomeSceneProps {
  scrollProgress: MutableRefObject<number>;
  mouse: MutableRefObject<{ x: number; y: number }>;
}

export default function HomeScene({ scrollProgress, mouse }: HomeSceneProps) {
  return (
    <>
      <Atmosphere color="#0e1e2c" near={20} far={110} />
      <CameraController
        scrollProgress={scrollProgress}
        mouse={mouse}
        maxDepth={110}
        startZ={5}
      />
      <Particles
        count={800}
        color="#fcfcfc"
        size={0.035}
        speed={0.2}
        depthRange={[15, -120]}
        spread={14}
      />
      <Particles
        count={200}
        color="#c0a080"
        size={0.05}
        speed={0.1}
        depthRange={[5, -100]}
        spread={10}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[0]}
        position={[-3.5, 1.5, -25]}
        width={2.8}
        height={1.9}
        floatAmp={0.2}
        floatSpeed={0.4}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[1]}
        position={[3.8, -0.5, -45]}
        width={3}
        height={2}
        floatAmp={0.15}
        floatSpeed={0.35}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[2]}
        position={[-4, 1, -65]}
        width={2.5}
        height={1.7}
        floatAmp={0.18}
        floatSpeed={0.45}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[3]}
        position={[4.2, -1, -85]}
        width={2.6}
        height={1.8}
        floatAmp={0.22}
        floatSpeed={0.3}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[4]}
        position={[-3, 2, -105]}
        width={2.4}
        height={1.6}
        floatAmp={0.15}
        floatSpeed={0.5}
      />
    </>
  );
}
