import { useRef, useMemo, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Plane } from '@react-three/drei';
import * as THREE from 'three';

interface FloatingImagePlaneProps {
  imageUrl: string;
  position: [number, number, number];
  width?: number;
  height?: number;
  floatAmp?: number;
  floatSpeed?: number;
  label?: string;
}

function useSafeTexture(url: string) {
  const [texture, setTexture] = useState<THREE.Texture | null>(null);

  useEffect(() => {
    let cancelled = false;
    const loader = new THREE.TextureLoader();
    loader.load(
      url,
      (tex) => {
        if (!cancelled) {
          tex.colorSpace = THREE.SRGBColorSpace;
          setTexture(tex);
        }
      },
      undefined,
      () => {}
    );
    return () => { cancelled = true; };
  }, [url]);

  return texture;
}

export default function FloatingImagePlane({
  imageUrl,
  position,
  width = 3,
  height = 2,
  floatAmp = 0.15,
  floatSpeed = 0.5,
}: FloatingImagePlaneProps) {
  const ref = useRef<THREE.Mesh>(null);
  const texture = useSafeTexture(imageUrl);
  const offset = useMemo(() => Math.random() * Math.PI * 2, []);
  const timeRef = useRef(0);

  useFrame((_, delta) => {
    if (!ref.current) return;
    timeRef.current += delta;
    const t = timeRef.current * floatSpeed + offset;
    ref.current.position.y = position[1] + Math.sin(t) * floatAmp;
    ref.current.rotation.z = Math.sin(t * 0.5) * 0.02;
  });

  if (!texture) return null;

  return (
    <group position={position}>
      <Plane ref={ref} args={[width, height]}>
        <meshBasicMaterial map={texture} toneMapped={false} />
      </Plane>
      <mesh position={[0, 0, -0.05]}>
        <planeGeometry args={[width + 0.06, height + 0.06]} />
        <meshBasicMaterial color="#fcfcfc" opacity={0.15} transparent depthWrite={false} />
      </mesh>
    </group>
  );
}
