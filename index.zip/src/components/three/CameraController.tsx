import { useFrame, useThree } from '@react-three/fiber';
import { useRef, useEffect, MutableRefObject } from 'react';

interface CameraControllerProps {
  scrollProgress: MutableRefObject<number>;
  mouse?: MutableRefObject<{ x: number; y: number }>;
  maxDepth?: number;
  startZ?: number;
}

export default function CameraController({
  scrollProgress,
  mouse,
  maxDepth = 90,
  startZ = 5,
}: CameraControllerProps) {
  const { camera } = useThree();
  const currentZ = useRef(startZ);
  const mouseX = useRef(0);
  const mouseY = useRef(0);

  useEffect(() => {
    camera.position.set(0, 0, startZ);
    camera.lookAt(0, 0, -10);
  }, [camera, startZ]);

  useFrame(() => {
    const targetZ = startZ - scrollProgress.current * maxDepth;
    currentZ.current += (targetZ - currentZ.current) * 0.06;

    if (mouse) {
      mouseX.current += (mouse.current.x - mouseX.current) * 0.04;
      mouseY.current += (mouse.current.y - mouseY.current) * 0.04;
    }

    camera.position.x = mouseX.current * 1.5;
    camera.position.y = mouseY.current * 1.0;
    camera.position.z = currentZ.current;
    camera.lookAt(mouseX.current * 0.3, mouseY.current * 0.2, currentZ.current - 10);
  });

  return null;
}
