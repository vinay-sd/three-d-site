import { MutableRefObject } from 'react';
import CameraController from './CameraController';
import Particles from './Particles';
import FloatingImagePlane from './FloatingImagePlane';
import Atmosphere from './Atmosphere';
import { galleryImages } from '../../data';

interface FlightLogSceneProps {
  scrollProgress: MutableRefObject<number>;
  mouse: MutableRefObject<{ x: number; y: number }>;
}

export default function FlightLogScene({ scrollProgress, mouse }: FlightLogSceneProps) {
  return (
    <>
      <Atmosphere color="#0e1e2c" near={10} far={85} />
      <CameraController
        scrollProgress={scrollProgress}
        mouse={mouse}
        maxDepth={80}
        startZ={5}
      />
      <Particles
        count={500}
        color="#fcfcfc"
        size={0.03}
        speed={0.15}
        depthRange={[8, -90]}
        spread={12}
      />
      <Particles
        count={120}
        color="#c0a080"
        size={0.045}
        speed={0.06}
        depthRange={[3, -80]}
        spread={9}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[0]}
        position={[3, 1, -20]}
        width={2.5}
        height={1.7}
        floatAmp={0.15}
        floatSpeed={0.4}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[3]}
        position={[-3.2, -0.5, -40]}
        width={2.4}
        height={1.6}
        floatAmp={0.18}
        floatSpeed={0.35}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[5]}
        position={[3.5, 1.2, -60]}
        width={2.6}
        height={1.8}
        floatAmp={0.2}
        floatSpeed={0.3}
      />
    </>
  );
}
