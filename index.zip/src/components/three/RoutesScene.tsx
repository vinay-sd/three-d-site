import { MutableRefObject } from 'react';
import CameraController from './CameraController';
import Particles from './Particles';
import FloatingImagePlane from './FloatingImagePlane';
import Atmosphere from './Atmosphere';
import { galleryImages } from '../../data';

interface RoutesSceneProps {
  scrollProgress: MutableRefObject<number>;
  mouse: MutableRefObject<{ x: number; y: number }>;
}

export default function RoutesScene({ scrollProgress, mouse }: RoutesSceneProps) {
  return (
    <>
      <Atmosphere color="#0a1628" near={15} far={95} />
      <CameraController
        scrollProgress={scrollProgress}
        mouse={mouse}
        maxDepth={95}
        startZ={5}
      />
      <Particles
        count={700}
        color="#8b9cb0"
        size={0.03}
        speed={0.18}
        depthRange={[10, -105]}
        spread={15}
      />
      <Particles
        count={150}
        color="#2a5c82"
        size={0.06}
        speed={0.08}
        depthRange={[5, -90]}
        spread={12}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[0]}
        position={[3.5, 1.2, -22]}
        width={2.8}
        height={1.9}
        floatAmp={0.18}
        floatSpeed={0.4}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[1]}
        position={[-3.8, -0.8, -42]}
        width={3}
        height={2}
        floatAmp={0.2}
        floatSpeed={0.35}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[2]}
        position={[4, 1.5, -62]}
        width={2.5}
        height={1.7}
        floatAmp={0.15}
        floatSpeed={0.45}
      />
      <FloatingImagePlane
        imageUrl={galleryImages[4]}
        position={[-4.2, -0.5, -82]}
        width={2.6}
        height={1.8}
        floatAmp={0.2}
        floatSpeed={0.3}
      />
    </>
  );
}
