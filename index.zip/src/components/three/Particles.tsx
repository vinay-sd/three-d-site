import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ParticlesProps {
  count?: number;
  color?: string;
  size?: number;
  speed?: number;
  depthRange?: [number, number];
  spread?: number;
}

export default function Particles({
  count = 600,
  color = '#fcfcfc',
  size = 0.04,
  speed = 0.15,
  depthRange = [10, -110],
  spread = 12,
}: ParticlesProps) {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count * 3; i += 3) {
      pos[i] = (Math.random() - 0.5) * spread * 2;
      pos[i + 1] = (Math.random() - 0.5) * spread * 1.2;
      pos[i + 2] = depthRange[0] + Math.random() * (depthRange[1] - depthRange[0]);
    }
    return pos;
  }, [count, spread, depthRange]);

  const sizes = useMemo(() => {
    const s = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      s[i] = 0.3 + Math.random() * 0.7;
    }
    return s;
  }, [count]);

  const velocities = useMemo(() => {
    const v = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      v[i] = 0.1 + Math.random() * speed;
    }
    return v;
  }, [count, speed]);

  useFrame((_, delta) => {
    if (!ref.current) return;
    const pos = ref.current.geometry.attributes.position.array as Float32Array;
    for (let i = 2; i < pos.length; i += 3) {
      pos[i] += velocities[Math.floor(i / 3)] * delta * 2;
      if (pos[i] > depthRange[0]) {
        pos[i] = depthRange[1];
        pos[i - 2] = (Math.random() - 0.5) * spread * 2;
        pos[i - 1] = (Math.random() - 0.5) * spread * 1.2;
      }
    }
    pos[2] += 0;
    ref.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-size"
          count={count}
          array={sizes}
          itemSize={1}
        />
      </bufferGeometry>
      <pointsMaterial
        size={size}
        color={color}
        transparent
        opacity={0.6}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}
