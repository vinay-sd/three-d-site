import { useMemo } from 'react';
import * as THREE from 'three';

interface AtmosphereProps {
  color?: string;
  near?: number;
  far?: number;
}

export default function Atmosphere({ color = '#0e1e2c', near = 15, far = 100 }: AtmosphereProps) {
  const fogColor = useMemo(() => new THREE.Color(color), [color]);
  return <fog attach="fog" args={[fogColor, near, far]} />;
}
