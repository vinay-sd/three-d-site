import { useRef, useMemo, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ImagePlaneProps {
  url: string;
  position: [number, number, number];
  rotation?: [number, number, number];
  width?: number;
  height?: number;
  opacity?: number;
  floatAmp?: number;
  floatSpeed?: number;
  frame?: boolean;
}

function useTextureLoader(url: string) {
  const [texture, setTexture] = useState<THREE.Texture | null>(null);
  const [errored] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const loader = new THREE.TextureLoader();
    loader.load(
      url,
      (tex) => {
        if (!cancelled) {
          tex.colorSpace = THREE.SRGBColorSpace;
          setTexture(tex);
        }
      },
      undefined,
      () => {}
    );
    return () => { cancelled = true; };
  }, [url]);

  return { texture, errored };
}

export function ImagePlane({
  url,
  position,
  rotation = [0, 0, 0],
  width = 120,
  height = 80,
  opacity = 0.88,
  floatAmp = 0.8,
  floatSpeed = 0.5,
  frame = true,
}: ImagePlaneProps) {
  const meshRef = useRef<THREE.Mesh>(null!);
  const timeRef = useRef(0);
  const { texture, errored } = useTextureLoader(url);
  const originY = position[1];

  useFrame((_, delta) => {
    if (!meshRef.current) return;
    timeRef.current += delta;
    meshRef.current.position.y =
      originY + Math.sin(timeRef.current * floatSpeed) * floatAmp;
  });

  if (errored) return null;

  return (
    <group position={position} rotation={new THREE.Euler(...rotation)}>
      <mesh ref={meshRef}>
        <planeGeometry args={[width, height]} />
        <meshBasicMaterial
          map={texture}
          transparent
          opacity={opacity}
          depthWrite={false}
          toneMapped={false}
        />
      </mesh>

      {frame && (
        <mesh position={[0, 0, -0.5]}>
          <planeGeometry args={[width + 2, height + 2]} />
          <meshBasicMaterial
            color="#c0a080"
            transparent
            opacity={0.12}
            depthWrite={false}
          />
        </mesh>
      )}
    </group>
  );
}

/* ─── Simple colour plane (for depth layers, fog cards, etc.) ─────────── */

interface ColourPlaneProps {
  position: [number, number, number];
  width?: number;
  height?: number;
  color?: string;
  opacity?: number;
}

export function ColourPlane({
  position,
  width = 200,
  height = 120,
  color = '#fcfcfc',
  opacity = 0.04,
}: ColourPlaneProps) {
  return (
    <mesh position={position}>
      <planeGeometry args={[width, height]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={opacity}
        depthWrite={false}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}
