/**
 * Atmosphere components shared by all scenes.
 *
 * AtmosphereFog   — volumetric Fog2 on the scene
 * DustParticles   — 2000 softly drifting motes
 * AmbientLight    — warm ambient + directional key light
 * EquirectEnv     — loads the existing /360.jpeg as an HDR environment
 */

import { useRef, useMemo } from 'react';
import { useFrame, useLoader } from '@react-three/fiber';
import { Fog } from 'three';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';

/* ─── Fog ─────────────────────────────────────────────────────────────── */

interface AtmosphereFogProps {
  color?: string;
  near?: number;
  far?: number;
}

export function AtmosphereFog({
  color = '#0a0f1a',
  near = 200,
  far = 3000,
}: AtmosphereFogProps) {
  const { scene } = useThree();
  useMemo(() => {
    scene.fog = new Fog(color, near, far);
    return () => {
      scene.fog = null;
    };
  }, [scene, color, near, far]);
  return null;
}

/* ─── Dust / Particle field ───────────────────────────────────────────── */

interface DustParticlesProps {
  count?: number;
  spread?: number;
  depth?: number;
  size?: number;
  color?: string;
  opacity?: number;
}

export function DustParticles({
  count = 2000,
  spread = 300,
  depth = 4000,
  size = 1.2,
  color = '#c8b89a',
  opacity = 0.35,
}: DustParticlesProps) {
  const meshRef = useRef<THREE.Points>(null!);

  const [positions, speeds] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const spd = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos[i * 3 + 0] = (Math.random() - 0.5) * spread;
      pos[i * 3 + 1] = (Math.random() - 0.5) * spread * 0.6;
      pos[i * 3 + 2] = Math.random() * -depth;
      spd[i] = 0.3 + Math.random() * 0.7;
    }
    return [pos, spd];
  }, [count, spread, depth]);

  const dustTimeRef = useRef(0);

  useFrame((_, delta) => {
    if (!meshRef.current) return;
    dustTimeRef.current += delta;
    const t = dustTimeRef.current;
    const pos = meshRef.current.geometry.attributes.position
      .array as Float32Array;
    for (let i = 0; i < count; i++) {
      pos[i * 3 + 1] += speeds[i] * 0.015;
      pos[i * 3 + 0] += Math.sin(t * 0.2 + i) * 0.008;
      if (pos[i * 3 + 1] > spread * 0.3) {
        pos[i * 3 + 1] = -spread * 0.3;
      }
    }
    meshRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={size}
        color={color}
        transparent
        opacity={opacity}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
}

/* ─── Lighting ────────────────────────────────────────────────────────── */

interface SceneLightsProps {
  ambientIntensity?: number;
  dirIntensity?: number;
  dirColor?: string;
}

export function SceneLights({
  ambientIntensity = 0.6,
  dirIntensity = 1.2,
  dirColor = '#d4c5a9',
}: SceneLightsProps) {
  return (
    <>
      <ambientLight intensity={ambientIntensity} color="#1a1f2e" />
      <directionalLight
        position={[50, 80, -100]}
        intensity={dirIntensity}
        color={dirColor}
      />
      <pointLight position={[0, 30, -200]} intensity={0.4} color="#4a7fa8" />
      <pointLight position={[0, -20, -600]} intensity={0.3} color="#c0a080" />
    </>
  );
}

/* ─── Equirect background from existing 360.jpeg ─────────────────────── */

export function EquirectBackground() {
  const texture = useLoader(THREE.TextureLoader, '/360.jpeg');

  useMemo(() => {
    texture.mapping = THREE.EquirectangularReflectionMapping;
    texture.colorSpace = THREE.SRGBColorSpace;
  }, [texture]);

  const { scene } = useThree();

  useMemo(() => {
    scene.background = texture;
    scene.environment = texture;
  }, [scene, texture]);

  return null;
}

/* ─── Floating decorative ring ────────────────────────────────────────── */

interface FloatingRingProps {
  position: [number, number, number];
  radius?: number;
  tubeRadius?: number;
  color?: string;
  opacity?: number;
  rotSpeed?: number;
}

export function FloatingRing({
  position,
  radius = 40,
  tubeRadius = 0.3,
  color = '#c0a080',
  opacity = 0.15,
  rotSpeed = 0.003,
}: FloatingRingProps) {
  const ref = useRef<THREE.Mesh>(null!);
  useFrame(() => {
    ref.current.rotation.x += rotSpeed;
    ref.current.rotation.y += rotSpeed * 0.7;
  });
  return (
    <mesh ref={ref} position={position}>
      <torusGeometry args={[radius, tubeRadius, 8, 80]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={opacity}
        wireframe={false}
      />
    </mesh>
  );
}
