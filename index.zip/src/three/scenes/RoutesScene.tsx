/**
 * RoutesScene
 *
 * Three.js world for /routes (Destinations page).
 *
 * Five regions, each at -600z intervals.
 * Images flank the path left and right; the DOM glass cards
 * are layered on top by the RoutesPage DOM overlay system.
 */

import {
  AtmosphereFog,
  DustParticles,
  SceneLights,
  EquirectBackground,
  FloatingRing,
} from '../components/Atmosphere';
import { ImagePlane, ColourPlane } from '../components/ImagePlane';
import { useCinematicCamera } from '../useCinematicCamera';
import { galleryImages } from '../../data';

const regionPlanes = [
  // Europe
  { url: galleryImages[0], pos: [-170,  15, -650]  as [number, number, number], rot: [0,  0.2, 0] as [number, number, number] },
  // Asia
  { url: galleryImages[1], pos: [ 160, -10, -1250] as [number, number, number], rot: [0, -0.2, 0] as [number, number, number] },
  // Middle East
  { url: galleryImages[2], pos: [-150,  20, -1850] as [number, number, number], rot: [0,  0.15, 0] as [number, number, number] },
  // Africa
  { url: galleryImages[4], pos: [ 180, -15, -2450] as [number, number, number], rot: [0, -0.15, 0] as [number, number, number] },
  // Americas
  { url: galleryImages[5], pos: [-140,   5, -3050] as [number, number, number], rot: [0,  0.1, 0] as [number, number, number] },
];

// Secondary companion images (other side of path)
const companionPlanes = [
  { url: galleryImages[1], pos: [ 155,  -5, -700]  as [number, number, number], rot: [0, -0.1, 0] as [number, number, number] },
  { url: galleryImages[2], pos: [-130,  10, -1300] as [number, number, number], rot: [0,  0.12, 0] as [number, number, number] },
  { url: galleryImages[3], pos: [ 165,  -8, -1900] as [number, number, number], rot: [0, -0.08, 0] as [number, number, number] },
  { url: galleryImages[0], pos: [-170,   0, -2500] as [number, number, number], rot: [0,  0.1, 0] as [number, number, number] },
  { url: galleryImages[4], pos: [ 145, -12, -3100] as [number, number, number], rot: [0, -0.1, 0] as [number, number, number] },
];

export default function RoutesScene() {
  useCinematicCamera({ totalDepth: 3200 });

  return (
    <>
      <EquirectBackground />
      <AtmosphereFog color="#080c16" near={300} far={3500} />
      <SceneLights ambientIntensity={0.55} dirIntensity={1.1} dirColor="#d0c8b0" />
      <DustParticles count={1500} spread={260} depth={3800} opacity={0.22} />

      {/* Zone hazes */}
      {regionPlanes.map((_, i) => (
        <ColourPlane
          key={`haze-${i}`}
          position={[0, 0, -(i + 1) * 600 - 50] as [number, number, number]}
          width={700}
          height={350}
          color="#2a5c82"
          opacity={0.025}
        />
      ))}

      {/* Primary destination images */}
      {regionPlanes.map((p, i) => (
        <ImagePlane
          key={`reg-${i}`}
          url={p.url}
          position={p.pos}
          rotation={p.rot}
          width={115}
          height={76}
          opacity={0.85}
          floatAmp={1.0}
          floatSpeed={0.3 + i * 0.04}
        />
      ))}

      {/* Companion images (smaller, further offset) */}
      {companionPlanes.map((p, i) => (
        <ImagePlane
          key={`comp-${i}`}
          url={p.url}
          position={p.pos}
          rotation={p.rot}
          width={80}
          height={54}
          opacity={0.55}
          floatAmp={0.7}
          floatSpeed={0.25 + i * 0.03}
        />
      ))}

      {/* Decorative rings marking each region transition */}
      {[600, 1200, 1800, 2400, 3000].map((depth, i) => (
        <FloatingRing
          key={`ring-${i}`}
          position={[i % 2 === 0 ? 10 : -10, 0, -depth]}
          radius={55 + i * 5}
          opacity={0.06}
          rotSpeed={0.002 + i * 0.0005}
        />
      ))}

      {/* End plane — signals the world continues */}
      <ColourPlane position={[0, 0, -3600]} width={900} height={500} color="#c0a080" opacity={0.03} />
    </>
  );
}
