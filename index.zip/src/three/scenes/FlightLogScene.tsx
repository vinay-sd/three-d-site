/**
 * FlightLogScene
 *
 * Three.js world for /flight-log (About page).
 *
 * More contemplative, fewer image planes — relies on
 * atmospheric geometry and deeper fog for an introspective feel.
 */

import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import {
  AtmosphereFog,
  DustParticles,
  SceneLights,
  EquirectBackground,
  FloatingRing,
} from '../components/Atmosphere';
import { ImagePlane, ColourPlane } from '../components/ImagePlane';
import { useCinematicCamera } from '../useCinematicCamera';
import { galleryImages } from '../../data';

/* Sparse image planes — the FlightLog page is text/story heavy */
const imagePlanesData = [
  { url: galleryImages[5], pos: [-160, 10, -700]  as [number, number, number], rot: [0,  0.18, 0] as [number, number, number] },
  { url: galleryImages[0], pos: [ 150, -8, -1500] as [number, number, number], rot: [0, -0.15, 0] as [number, number, number] },
  { url: galleryImages[3], pos: [-140, 15, -2200] as [number, number, number], rot: [0,  0.10, 0] as [number, number, number] },
];

export default function FlightLogScene() {
  useCinematicCamera({ totalDepth: 2800 });

  return (
    <>
      <EquirectBackground />
      {/* Slightly warmer, more introspective fog */}
      <AtmosphereFog color="#0a0c0f" near={250} far={2800} />
      <SceneLights
        ambientIntensity={0.45}
        dirIntensity={0.9}
        dirColor="#d8cfc0"
      />
      <DustParticles count={1200} spread={240} depth={3200} opacity={0.20} size={1.0} />

      {imagePlanesData.map((p, i) => (
        <ImagePlane
          key={i}
          url={p.url}
          position={p.pos}
          rotation={p.rot}
          width={100}
          height={66}
          opacity={0.75}
          floatAmp={0.9}
          floatSpeed={0.28 + i * 0.05}
        />
      ))}

      <ColourPlane position={[0, 0, -1000]} width={600} height={300} color="#c0a080" opacity={0.03} />
      <ColourPlane position={[0, 0, -2000]} width={700} height={350} color="#2a5c82" opacity={0.035} />

      <FloatingRing position={[0, 0, -800]}  radius={50} opacity={0.07} />
      <FloatingRing position={[0, 0, -1800]} radius={70} opacity={0.05} rotSpeed={0.0018} />
      <FloatingRing position={[0, 0, -2600]} radius={90} opacity={0.04} rotSpeed={0.0012} />

      {/* Abstract constellations — small sphere clusters */}
      <ConstellationField />
    </>
  );
}

/* ─── Small dotted star-like clusters ────────────────────────────────── */
function ConstellationField() {
  const ref = useRef<THREE.Points>(null!);

  const [positions] = useMemo(() => {
    const count = 300;
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = 80 + Math.random() * 120;
      pos[i * 3 + 0] = Math.cos(angle) * radius;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 100;
      pos[i * 3 + 2] = -200 - Math.random() * 2800;
    }
    return [pos];
  }, []);

  const orbitTimeRef = useRef(0);

  useFrame((_, delta) => {
    if (!ref.current) return;
    orbitTimeRef.current += delta;
    ref.current.rotation.z = Math.sin(orbitTimeRef.current * 0.05) * 0.02;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={1.5}
        color="#d4c8b0"
        transparent
        opacity={0.5}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
}
