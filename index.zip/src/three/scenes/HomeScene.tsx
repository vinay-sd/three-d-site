/**
 * HomeScene
 *
 * Three.js world for the Home page.
 *
 * Depth map (camera travels -z):
 *   0        → Hero
 *   -600     → Trusted stats layer
 *   -1200    → Features layer
 *   -1800    → Destinations gallery
 *   -2400    → Experiences layer
 *   -3000    → Testimonials
 *   -3600    → CTA
 *
 * Camera starts at z=0 and travels to z=-3600 as the user scrolls.
 * totalDepth=3600 matches the 1200vh scroll container in HomePage.
 *
 * The DOM (glass cards, text) is rendered on top; this scene only
 * provides depth, atmosphere, image planes, and environmental cues.
 */

import { useMemo } from 'react';
import * as THREE from 'three';
import {
  AtmosphereFog,
  DustParticles,
  SceneLights,
  EquirectBackground,
  FloatingRing,
} from '../components/Atmosphere';
import { ImagePlane, ColourPlane } from '../components/ImagePlane';
import { useCinematicCamera } from '../useCinematicCamera';
import { galleryImages, experienceImages } from '../../data';

/* Destination images mapped to world positions ──────────────────────── */
const destinationPlanes = [
  { url: galleryImages[0], pos: [-160,  10, -1800] as [number, number, number], rot: [0,  0.15, 0] as [number, number, number] },
  { url: galleryImages[1], pos: [ 140, -15, -1950] as [number, number, number], rot: [0, -0.18, 0] as [number, number, number] },
  { url: galleryImages[2], pos: [-120,  25, -2100] as [number, number, number], rot: [0,  0.10, 0] as [number, number, number] },
  { url: galleryImages[3], pos: [ 160,   0, -2250] as [number, number, number], rot: [0, -0.12, 0] as [number, number, number] },
  { url: galleryImages[4], pos: [-180, -10, -2400] as [number, number, number], rot: [0,  0.08, 0] as [number, number, number] },
  { url: galleryImages[5], pos: [ 130,  15, -2550] as [number, number, number], rot: [0, -0.10, 0] as [number, number, number] },
];

const experiencePlanes = [
  { url: experienceImages[0], pos: [-100,  20, -2600] as [number, number, number], rot: [0,  0.05, 0] as [number, number, number] },
  { url: experienceImages[1], pos: [  80, -10, -2700] as [number, number, number], rot: [0, -0.08, 0] as [number, number, number] },
  { url: experienceImages[2], pos: [-160,   5, -2800] as [number, number, number], rot: [0,  0.12, 0] as [number, number, number] },
];

export default function HomeScene() {
  // 3600 units deep × (1200vh / 3600units) = 1vh ≈ 1px of camera travel
  useCinematicCamera({ totalDepth: 3600 });

  return (
    <>
      {/* Environment */}
      <EquirectBackground />
      <AtmosphereFog color="#080d18" near={400} far={4000} />
      <SceneLights ambientIntensity={0.5} dirIntensity={1.0} />
      <DustParticles count={1800} spread={280} depth={4000} opacity={0.28} />

      {/* Depth layer colour planes — give a sense of "zones" ─────────── */}
      {/* Hero zone: very open, no planes */}
      
      {/* Stats zone: faint horizontal band */}
      <ColourPlane position={[0, 0, -600]} width={600} height={300} color="#c0a080" opacity={0.025} />

      {/* Destinations zone: the hero area of the world */}
      <ColourPlane position={[0, 0, -1800]} width={800} height={400} color="#2a5c82" opacity={0.04} />

      {/* Destination image planes (float left/right of flight path) */}
      {destinationPlanes.map((p, i) => (
        <ImagePlane
          key={i}
          url={p.url}
          position={p.pos}
          rotation={p.rot}
          width={110}
          height={72}
          opacity={0.82}
          floatAmp={1.2}
          floatSpeed={0.35 + i * 0.05}
        />
      ))}

      {/* Experience planes */}
      {experiencePlanes.map((p, i) => (
        <ImagePlane
          key={`exp-${i}`}
          url={p.url}
          position={p.pos}
          rotation={p.rot}
          width={90}
          height={60}
          opacity={0.72}
          floatAmp={0.8}
          floatSpeed={0.4 + i * 0.06}
        />
      ))}

      {/* CTA zone: a bright haze plane far ahead */}
      <ColourPlane position={[0, 0, -3500]} width={1000} height={600} color="#fcfcfc" opacity={0.03} />

      {/* Decorative rings along the tunnel */}
      <FloatingRing position={[0,  0, -900]}  radius={60}  opacity={0.08} />
      <FloatingRing position={[20, 10, -1500]} radius={45}  opacity={0.06} rotSpeed={0.002} />
      <FloatingRing position={[-15, -5, -2200]} radius={80}  opacity={0.05} rotSpeed={0.0015} />
      <FloatingRing position={[0, 0, -3200]}  radius={100} opacity={0.04} rotSpeed={0.001} />

      {/* Distant landmark geometry: simple geometric shapes suggesting architecture */}
      <LandmarkGeometry />
    </>
  );
}

/* ─── Landmark geometry (abstract city silhouettes in the distance) ───── */

function LandmarkGeometry() {
  // A cluster of tall boxes at the "horizon" of the tunnel
  const towers = useMemo(() => [
    { x: -300, y: -60, z: -3800, w: 8,  h: 140, d: 8  },
    { x: -250, y: -50, z: -3900, w: 6,  h: 100, d: 6  },
    { x:  280, y: -55, z: -3800, w: 10, h: 160, d: 10 },
    { x:  240, y: -45, z: -3950, w: 7,  h: 80,  d: 7  },
    { x:  0,   y: -40, z: -4200, w: 12, h: 200, d: 12 },
    { x: -80,  y: -60, z: -4100, w: 5,  h: 120, d: 5  },
    { x:  90,  y: -60, z: -4150, w: 5,  h: 90,  d: 5  },
  ], []);

  return (
    <>
      {towers.map((t, i) => (
        <mesh key={i} position={[t.x, t.y, t.z]}>
          <boxGeometry args={[t.w, t.h, t.d]} />
          <meshBasicMaterial
            color="#1a2030"
            transparent
            opacity={0.4}
          />
        </mesh>
      ))}
    </>
  );
}
