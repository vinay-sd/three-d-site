import { Component, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { useLocation } from 'react-router-dom';
import { PerformanceMonitor, AdaptiveDpr } from '@react-three/drei';
import HomeScene from './scenes/HomeScene';
import RoutesScene from './scenes/RoutesScene';
import FlightLogScene from './scenes/FlightLogScene';

class CanvasErrorBoundary extends Component<{ children: React.ReactNode }> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  render() {
    return this.state.hasError ? null : this.props.children;
  }
}

function SceneRouter() {
  const { pathname } = useLocation();
  if (pathname === '/routes') return <RoutesScene />;
  if (pathname === '/flight-log') return <FlightLogScene />;
  return <HomeScene />;
}

export default function WorldCanvas() {
  return (
    <Canvas
      className="!fixed inset-0 z-0"
      style={{ position: 'fixed', inset: 0, zIndex: 0 }}
      camera={{ fov: 60, near: 0.1, far: 8000, position: [0, 0, 0] }}
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: 'high-performance',
        stencil: false,
        depth: true,
      }}
      dpr={[1, 1.5]}
      frameloop="always"
      onError={() => {}}
    >
      <AdaptiveDpr pixelated />
      <PerformanceMonitor
        onDecline={() => {
          /* optionally lower quality */
        }}
      />
      <CanvasErrorBoundary>
        <Suspense fallback={null}>
          <SceneRouter />
        </Suspense>
      </CanvasErrorBoundary>
    </Canvas>
  );
}
