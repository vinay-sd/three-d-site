/**
 * useCinematicCamera
 *
 * Wires GSAP ScrollTrigger to the R3F camera's z-position.
 * Also adds a gentle mouse-parallax tilt on desktop.
 *
 * Usage:
 *   useCinematicCamera({ totalDepth: 6000, scrollHeight: '800vh' })
 *
 * This replaces the old pattern of:
 *   gsap.to(cameraRef.current, { z: totalDepth * 0.8, scrollTrigger: {...} })
 * …but now drives camera.position.z in THREE.js space so geometry
 * never rasterises at wrong resolution.
 */

import { useRef, useEffect } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface CinematicCameraOptions {
  /** Total depth the camera travels (positive = forward into -z) */
  totalDepth: number;
  /** Whether to add mouse parallax tilt (desktop only) */
  mouseTilt?: boolean;
}

export function useCinematicCamera({
  totalDepth,
  mouseTilt = true,
}: CinematicCameraOptions) {
  const { camera } = useThree();

  // target values we lerp toward each frame
  const targetRef = useRef({ z: 0, rotX: 0, rotY: 0 });
  const triggerRef = useRef<ScrollTrigger | null>(null);

  useEffect(() => {
    // Proxy object GSAP animates; we read it in useFrame
    const proxy = { z: 0 };

    triggerRef.current = ScrollTrigger.create({
      trigger: document.body,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1.5,
      onUpdate: (self) => {
        proxy.z = self.progress * totalDepth;
        targetRef.current.z = proxy.z;
      },
    });

    return () => {
      triggerRef.current?.kill();
    };
  }, [totalDepth]);

  useEffect(() => {
    if (!mouseTilt || window.innerWidth < 768) return;

    const onMouse = (e: MouseEvent) => {
      const nx = (e.clientX / window.innerWidth - 0.5) * 2;
      const ny = (e.clientY / window.innerHeight - 0.5) * 2;
      targetRef.current.rotX = -ny * 0.03;
      targetRef.current.rotY = nx * 0.04;
    };

    window.addEventListener('mousemove', onMouse, { passive: true });
    return () => window.removeEventListener('mousemove', onMouse);
  }, [mouseTilt]);

  useFrame(() => {
    const t = targetRef.current;
    // Smooth camera Z toward target (lerp factor 0.05 = buttery)
    camera.position.z += (-t.z - camera.position.z) * 0.06;
    camera.rotation.x += (t.rotX - camera.rotation.x) * 0.04;
    camera.rotation.y += (t.rotY - camera.rotation.y) * 0.04;
  });
}
